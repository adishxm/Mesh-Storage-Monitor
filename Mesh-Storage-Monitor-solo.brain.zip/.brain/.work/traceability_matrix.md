# Traceability Matrix

| Research/vision item | Workstream | Phase | Test | Report/gate |
|---|---|---|---|---|
| 1–3% storage contribution | WS01/WS03 | core/quota + enrollment | quota/accounting | MVP |
| Chunk and encrypt files | WS01 | storage core | round-trip/corruption | MVP |
| Reed-Solomon recovery | WS01/WS04 | erasure + repair | missing shards/offline node | MVP |
| Global device network | WS02/WS07 | relay/global connectivity | separate networks | production |
| Native Android node | WS05 | Android MVP/production | lifecycle/storage | production |
| No central plaintext | WS01/WS03 | encryption/control plane | leakage tests | production |
| Temporary offline vs leave | WS02/WS04 | lifecycle/repair | pause/leave | MVP |
| 30-day retention | WS03/WS04 | lifecycle policy | deletion/restore | production |
| Worldwide strangers | WS03/WS04/WS07 | enrollment/proof/credits | Sybil/abuse/relay | production |
