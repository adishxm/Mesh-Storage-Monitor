# Shared Interface Contracts

## Shard format
Versioned header, file/chunk/shard identifiers, encryption metadata, content hash, length, and authenticated payload.

## Manifest
File ID, root hash, ordered chunks, `k`, `n`, shard hashes, placement IDs, format version, and lifecycle state.

## Device identity
Peer ID, public key, organization/device IDs, capabilities, software version, revocation state, and last-seen information.

## Join invitation
Signed network/organization claim, bootstrap addresses, expiry, single-use nonce, capabilities, and issuer key ID. Never private keys.

## Events
Event ID, tenant ID, request/causation ID, schema version, timestamp, actor/device, type, and redacted payload.

## Status
Freshness timestamp, node state, peer state, quota, redundancy health, audit result, repair state, and source node.
